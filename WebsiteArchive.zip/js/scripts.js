function replace() {
    document.getElementById("play-img").setAttribute("hidden");
    document.getElementById("play-video").removeAttribute("hidden");
}